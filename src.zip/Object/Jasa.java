package Object;
public class Jasa
{
    private int kode_jasa;
    private String nama_jasa;
    private int harga;
    
    public Jasa(){}

    public Jasa(int kode_jasa, String nama_jasa, int harga) {
        this.kode_jasa = kode_jasa;
        this.nama_jasa = nama_jasa;
        this.harga = harga;
    }

    public int getKode_jasa() {
        return kode_jasa;
    }
    public void setKode_jasa(int kode_jasa) {
        this.kode_jasa = kode_jasa;
    }
    public String getNama_jasa() {
        return nama_jasa;
    }
    public void setNama_jasa(String nama_jasa) {
        this.nama_jasa = nama_jasa;
    }
    public int getHarga() {
        return harga;
    }
    public void setHarga(int harga) {
        this.harga = harga;
    }
    
    
}