package Object;
public class User
{
    private int kode_user;
    private String nama_user;
    private String username;
    private String password;
    private char jenis_kelamin;
    private String alamat;
    private String no_telp;
    private String status; //Master or Employee
    
    public User(){}

    public User(int kode_user, String nama_user, String username, String password, char jenis_kelamin, String alamat, String no_telp, String status) {
        this.kode_user = kode_user;
        this.nama_user = nama_user;
        this.username = username;
        this.password = password;
        this.jenis_kelamin = jenis_kelamin;
        this.alamat = alamat;
        this.no_telp = no_telp;
        this.status = status;
    }

    public int getKode_user() {
        return kode_user;
    }
    public void setKode_user(int kode_user) {
        this.kode_user = kode_user;
    }
    public String getNama_user() {
        return nama_user;
    }
    public void setNama_user(String nama_user) {
        this.nama_user = nama_user;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public char getJenis_kelamin() {
        return jenis_kelamin;
    }
    public void setJenis_kelamin(char jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }
    public String getAlamat() {
        return alamat;
    }
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    public String getNo_telp() {
        return no_telp;
    }
    public void setNo_telp(String no_telp) {
        this.no_telp = no_telp;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    
}