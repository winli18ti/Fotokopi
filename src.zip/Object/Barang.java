package Object;
public class Barang
{
    private int kode_barang;
    private String nama_barang;
    private int harga_beli;
    private int harga_jual;
    private int stok;
    private String satuan;
    
    public Barang(){}

    public Barang(int kode_barang, String nama_barang, int harga_beli, int harga_jual, int stok, String satuan) {
        this.kode_barang = kode_barang;
        this.nama_barang = nama_barang;
        this.harga_beli = harga_beli;
        this.harga_jual = harga_jual;
        this.stok = stok;
        this.satuan = satuan;
    }

    public int getKode_barang() {
        return kode_barang;
    }
    public void setKode_barang(int kode_barang) {
        this.kode_barang = kode_barang;
    }
    public String getNama_barang() {
        return nama_barang;
    }
    public void setNama_barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }
    public int getHarga_beli() {
        return harga_beli;
    }
    public void setHarga_beli(int harga_beli) {
        this.harga_beli = harga_beli;
    }
    public int getHarga_jual() {
        return harga_jual;
    }
    public void setHarga_jual(int harga_jual) {
        this.harga_jual = harga_jual;
    }
    public int getStok() {
        return stok;
    }
    public void setStok(int stok) {
        this.stok = stok;
    }
    public String getSatuan() {
        return satuan;
    }
    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }
    
    
}