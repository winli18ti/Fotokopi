package Object;
public class Supplier
{
    private int kode_supplier;
    private String nama_supplier;
    private String alamat;
    private String no_telp;
    
    public Supplier(){}

    public int getKode_supplier() {
        return kode_supplier;
    }
    public void setKode_supplier(int kode_supplier) {
        this.kode_supplier = kode_supplier;
    }
    public String getNama_supplier() {
        return nama_supplier;
    }
    public void setNama_supplier(String nama_supplier) {
        this.nama_supplier = nama_supplier;
    }
    public String getAlamat() {
        return alamat;
    }
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    public String getNo_telp() {
        return no_telp;
    }
    public void setNo_telp(String no_telp) {
        this.no_telp = no_telp;
    }
    
    
}