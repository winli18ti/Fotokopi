package Database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Query
{
    Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    
    String dbUrl = String.format("jdbc:mysql://localhost:3306/%s","Fotokopi");
    String user = "root";
    String pass = null;
    
    public String login(String username,String password)
    {
        boolean found=false;
        String status="";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl,user,pass);
            stmt = con.createStatement();
            
            String querySec = "SLEECT username, password, status FROM user";
            rs = stmt.executeQuery(querySec);
            
            String tempUsername,tempPassword;
            while(rs.next())
            {
                tempUsername=rs.getString("username");
                tempPassword=rs.getString("password");
                
                if(username.equals(tempUsername)&&password.equals(tempPassword))
                {
                    found=true;
                    status=rs.getString("status");
                    break;
                }
            }
        }
        catch(ClassNotFoundException | SQLException e)
        {
            
        }
        finally
        {
            try
            {
                rs.close();
                stmt.close();
                con.close();
                
            }
            catch(SQLException e)
            {
                
            }
        }
        return status;
    }
    
    public boolean signUp(String nama_user,String username,String password,char jenis_kelamin,String alamat,String no_telp,String status)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl,user,pass);
            stmt = con.createStatement();
            
            String queryIns = String.format("INSERT INTO user(nama_user,username,password,jenis_kelamin,alamat,no_telp,status"
                    + " VALUES('%s','%s','%s','%c','%s','%s','%s')",
                    nama_user,username,password,jenis_kelamin,alamat,no_telp,status);
            stmt.executeUpdate(queryIns);
        }
        catch(ClassNotFoundException | SQLException e)
        {
            return false;
        }
        finally
        {
            try
            {
                stmt.close();
                con.close();
            }
            catch(SQLException e)
            {
                return false;
            }
        }
        return true;
    }
    
    public boolean insertBarang(String nama_barang,int harga_beli,int harga_jual,int stok,String satuan)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl,user,pass);
            stmt = con.createStatement();
            
            String queryIns = String.format("INSERT INTO barang(nama_barang,harga_beli,harga_jual,stok,satuan) "
                    + "VALUES('%s','%d','%d','%d','%s')",
                    nama_barang,harga_beli,harga_jual,stok,satuan);
            stmt.executeUpdate(queryIns);
        }
        catch(ClassNotFoundException | SQLException e)
        {
            return false;
        }
        finally
        {
            try
            {
                stmt.close();
                con.close();
            }
            catch(SQLException e)
            {
                return false;
            }
        }
        return true;
    }
    
    public boolean insertJasa(String nama_jasa,int harga)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl,user,pass);
            stmt = con.createStatement();
            
            String queryIns = String.format("INSERT INTO jasa(nama_jasa,harga) "
                    + "VALUES('%s','%d')",
                    nama_jasa,harga);
            stmt.executeUpdate(queryIns);
        }
        catch(ClassNotFoundException | SQLException e)
        {
            return false;
        }
        finally
        {
            try
            {
                stmt.close();
                con.close();
            }
            catch(SQLException e)
            {
                return false;
            }
        }
        return true;
    }
    
    public boolean insertSupplier(String nama_supplier,String alamat,String no_telp)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl,user,pass);
            stmt = con.createStatement();
            
            String queryIns = String.format("INSERT INTO supplier(nama_supplier,alamat,no_telp) "
                    + "VALUES('%s','%s','%s')",
                    nama_supplier,alamat,no_telp);
            stmt.executeUpdate(queryIns);
        }
        catch(ClassNotFoundException | SQLException e)
        {
            return false;
        }
        finally
        {
            try
            {
                stmt.close();
                con.close();
            }
            catch(SQLException e)
            {
                return false;
            }
        }
        return true;
    }
}